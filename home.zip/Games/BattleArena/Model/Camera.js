var Camera = (function () {

// private static var

// Contructor
    var ctor = function () {
        var self = this; // prevents overlaping this-context

// private var

// public instance only


// Getters & Setters

    };

// public static

// public shared
    ctor.prototype = {};

//  Inheritance
//  inherit(ctor, SuperClass);
    return ctor;
})();