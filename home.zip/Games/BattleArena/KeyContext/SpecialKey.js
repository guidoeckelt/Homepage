var SpecialKey = (function(){

// private static var

    var ctor = function () {
        var self = this; // prevents overlaping this-context
        
// private var

// public instance only


// Getters & Setters

    };

// public static
    ctor.CONTROL = "control";
    ctor.ALT = "alt";
    ctor.ALTGR = "alt_gr";
    ctor.SHIFT = "shift";
    ctor.CAPS = "caps";
    ctor.WINDOWS = "windows";

// public shared
    ctor.prototype = {

    };
    
//  Inheritance
//  inherit(ctor, SuperClass);
    return ctor;
})();