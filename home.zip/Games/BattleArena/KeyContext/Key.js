var Key = (function () {

// private static var

    var ctor = function () {
        var self = this; // prevents overlaping this-context

// private var

// public instance only


// Getters & Setters

    };

// public static
    ctor.w                  = "w";
    ctor.A                  = "a";
    ctor.S                  = "s";
    ctor.D                  = "d";

    ctor.ARROWUP            = "arrow_up";
    ctor.ARROWDOWN          = "arrow_down";
    ctor.ARROWLEFT          = "arrow_left";
    ctor.ARROWRIGHT         = "arrow_right";

    ctor.SPACE              = "space";

// public shared
    ctor.prototype = {

    };

//  Inheritance
//  inherit(ctor, SuperClass);
    return ctor;
})();