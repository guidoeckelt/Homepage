/**
 * Created by Guido on 02.08.2016.
 */
QUnit.test( "hello test", function( assert ) {
    assert.equal(2, 1, "Not Passed!");
});
QUnit.test( "hello test 2", function( assert ) {
    assert.equal(1, 1, "Passed!" );
});